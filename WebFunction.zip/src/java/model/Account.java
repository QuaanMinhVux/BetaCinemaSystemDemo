
package model;

/**
 *
 * @author SHD
 */
public class Account {
    
}